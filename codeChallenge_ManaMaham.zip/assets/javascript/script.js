window.addEventListener("load", function () {
  //   get form
  const form = document.querySelector("form");

  //   on submit
  form.addEventListener("submit", function (event) {
    event.preventDefault();

    // get value of username and password inputs
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // validate and redirect
    if(username === "Mana-Maham" && password === "M@n@-M@h@m"){
        window.location.href = "main.html";
    }
    else {
        alert("username or password is incorrect!")
    }

  });
  
});
